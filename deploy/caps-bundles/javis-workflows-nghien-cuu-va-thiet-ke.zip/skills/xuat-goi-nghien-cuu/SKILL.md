---
name: Xuất gói nghiên cứu
description: "Gom Markdown+ảnh nghiên cứu thành index, HTML, PDF (Chrome) và PPTX đơn giản."
description_en: "Pack research Markdown+images into index, HTML, PDF (Chrome) and simple PPTX."
group: Marketing
---

# Xuất gói nghiên cứu (PDF / PPTX)

## Khi nào dùng

- Đã có thư mục `sources/research/<slug>/` với các file `01`–`05` (hoặc tương đương).
- Cần giao nộp PDF báo cáo dài và/hoặc PPTX trình bày ngắn.

## Chuẩn bị

1. Xác định `slug` dự án (ASCII, gạch ngang).
2. Vault root = gốc brain đang làm việc.
3. Có **Google Chrome** (hoặc Chromium) trên máy để in PDF. Không có thì vẫn xuất HTML.
4. Ảnh minh họa nên nằm dưới `attachments/research/<slug>/` và đã nhúng relative path trong Markdown.

## Quy trình

1. Viết / cập nhật `00-index.md` (mục lục + đường dẫn file).
2. Chạy script từ **gốc vault** (hoặc truyền `--vault`):

```bash
python3 skills/xuat-goi-nghien-cuu/scripts/export_pack.py \
  --slug <slug> \
  --formats pdf,pptx,html \
  --title "Nghiên cứu thị trường - <tên>"
```

3. Kết quả mặc định: `exports/research/<slug>/`
   - `report.html` - xem / in tay
   - `report.pdf` - nếu Chrome có
   - `deck.pptx` - slide từ tiêu đề `##` / `###` trong proposal + findings
   - `manifest.json` - danh sách file đã gom

4. Báo user đường dẫn tuyệt đối hoặc relative trong vault; nhúng link markdown nếu chat dashboard.

## Bẫy

- Đường dẫn ảnh trong MD phải relative so với vault (`attachments/...`), không dùng absolute máy.
- PPTX này là deck tóm tắt (title + bullets), không thay PDF đầy đủ.
- Không có Chrome: đừng giả PDF đã tạo - chỉ giao HTML + MD.
- Script không gọi mạng; không cần API key.
