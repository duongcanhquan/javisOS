---
type: workflow
name: Brief báo chí sáng
slug: brief-bao-chi-sang
status: active
group: Nội dung
description: Lọc RSS cửa sổ sáng, tóm tắt theo chủ đề (mặc định giáo dục CĐ-ĐH), tối đa 10 link.
model: gemini-3.6-flash
model_provider: gemini
steps:
  - agent: tong-hop-bao-chi
    task: "Nạp skill tong-hop-bao-chi. Chủ đề từ {{input}} (trống = chủ đề mặc định trong Javis/bao-chi-cau-hinh.md). Lọc RSS 00:00 hôm qua→08:00 hôm nay (VN), tóm tắt theo chủ đề, tối đa 10 bài mới kèm link. Không bịa."
updated: 2026-09-06
---
Brief báo chí theo RSS. `/run brief-bao-chi-sang <chủ đề>` hoặc nhắc 8h sáng.
