---
type: workflow
name: Brief báo chí sáng - Giáo dục
slug: brief-bao-chi-sang
status: active
group: Nội dung
description: 8h sáng: tổng hợp RSS danh mục giao-duc, tóm tắt + tối đa 10 link gửi chat.
model: gemini-3.6-flash
model_provider: gemini
steps:
  - agent: tong-hop-bao-chi
    task: "Nạp skill tong-hop-bao-chi. Danh mục CỐ ĐỊNH: giao-duc (RSS giáo dục trong Javis/bao-chi-cau-hinh.md). Bỏ qua {{input}} nếu không phải giáo dục. Chạy fetch_rss.py --category giao-duc --limit 10. Cửa sổ 00:00 hôm qua→08:00 hôm nay (VN). Tóm tắt + tối đa 10 bài kèm link. Không bịa."
updated: 2026-09-06
---
Brief sáng giáo dục. Nhắc 8h hoặc `/run brief-bao-chi-sang`. Danh mục khác: gọi skill tay (vd tài chính).
