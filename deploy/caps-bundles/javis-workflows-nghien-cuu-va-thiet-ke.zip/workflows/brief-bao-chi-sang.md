---
type: workflow
name: Brief báo chí sáng - Giáo dục
slug: brief-bao-chi-sang
status: active
group: Nội dung
description: 8h sáng RSS giao-duc; mỗi tin ghi Báo + giờ xuất bản + link đọc; tối đa 10.
model: gemini-3.6-flash
model_provider: antigravity-cli
steps:
  - agent: tong-hop-bao-chi
    task: "Nạp skill tong-hop-bao-chi. Danh mục CỐ ĐỊNH giao-duc. fetch_rss.py --category giao-duc --limit 10. Cửa sổ 00:00 hôm qua→08:00 hôm nay. Tóm tắt + Tin mới: MỖI bài đủ Báo (source_name), Xuất bản (published_human), Link (url), tóm tắt 1 câu. Không bịa."
updated: 2026-09-06
---
Brief sáng giáo dục. Mỗi tin phải có tên báo, giờ xuất bản, link đọc.
