---
type: workflow
name: Nghiên cứu thị trường chuyên sâu
slug: nghien-cuu-thi-truong-chuyen-sau
status: on
group: Marketing
description: "Nghiên cứu chuyên sâu (JTBD/STEEPLE/SOM) → khảo sát → đối thủ → đồ họa → proposal nâng cấp → kiểm chứng → PDF/PPTX."
steps:
  - agent: nghien-cuu-thi-truong-sau
    task: "Brief: {{input}}. Tạo slug ASCII. Nạp skill nghien-cuu-thi-truong + deep-research. Viết 01-research-findings.md đủ: giả định, TAM/SAM/SOM (triangulation + 3 kịch bản nếu mới), JTBD 4 lực, Hệ thống 1/2, văn hóa vùng miền nếu có, đối thủ+white space, STEEPLE/pháp lý, SWOT, 5-7 insight then chốt + nguồn. Lưu sources/research/<slug>/01-research-findings.md. Cuối ghi SLUG=..."
  - agent: thiet-ke-khao-sat
    task: "Từ brief {{input}} và {{prev}}: thiết kế khảo sát giảm Say-Do gap, đo lo âu/sức ỳ/JTBD. Lưu sources/research/<slug>/02-survey-plan.md (đúng slug)."
  - agent: phan-tich-doi-thu-persona
    task: "Từ {{prev}} + 01-research-findings: đối thủ positioning/white space + persona vùng miền + JTBD 4 lực. Lưu sources/research/<slug>/03-competitors-personas.md."
  - agent: thiet-ke-do-hoa-minh-hoa
    task: "Từ insight {{prev}} + file research: visual SOM, bản đồ cạnh tranh, JTBD, funnel, cover proposal. Tạo ảnh nếu được phép. Lưu sources/research/<slug>/04-visual-brief.md."
  - agent: soan-proposal-chien-luoc
    task: "Nạp skill proposal-chien-luoc. Chưng cất 01–04 + brief {{input}} thành proposal đủ mục (Exec Summary ≤200 từ; KPI neo SOM base case; KD+MKT; rủi ro pháp lý NĐ13; consent). Lưu sources/research/<slug>/05-proposal.md."
    verify_agent: kiem-chung-nghien-cuu
    max_retries: 1
  - agent: kiem-chung-nghien-cuu
    task: "Kiểm chứng 01–05 theo checklist skill nghien-cuu-thi-truong + proposal-chien-luoc. Liệt kê FAIL + đoạn sửa cụ thể."
  - agent: soan-proposal-chien-luoc
    task: "Áp dụng chỉnh từ {{prev}} vào 05-proposal.md (và 01–03 nếu được chỉ). Giữ file sạch để xuất."
  - agent: xuat-goi-bao-cao
    task: "Nạp skill xuat-goi-nghien-cuu. Viết 00-index.md, xuất html+pdf+pptx vào exports/research/<slug>/. Báo đường dẫn. Title từ {{input}}."
updated: 2026-09-06
---

# Nghiên cứu thị trường chuyên sâu (gói giao nộp)

Pipeline thống nhất skill **`nghien-cuu-thi-truong`** ↔ **`proposal-chien-luoc`**: nghiên cứu đa chiều → khảo sát → đối thủ/persona → đồ họa → proposal → kiểm chứng → PDF/PPTX.

## Cách kích hoạt và chạy (chuẩn)

1. Chọn đúng **brain** đang có workflow này (vd Brain Default).
2. Vào **Studio → tab Workflows**.
3. Tìm thẻ **Nghiên cứu thị trường chuyên sâu**.
4. Trạng thái phải là **● Sẵn sàng** (`status: on`). Nếu thấy **Lưu trữ** / nút ▶ Chạy mờ → bấm **Kích hoạt**.
5. Bấm **▶ Chạy**.
6. Dán brief vào ô input, ví dụ:
   > Ngành giáo dục nghề, thị trường Hà Nội + HCM, sản phẩm khóa liên kết DN, mục tiêu proposal gửi BGH, ưu tiên PDF+PPTX, ngân sách marketing ước 200 triệu/quý.
7. Theo dõi bảng chạy từng bước (✓ / ✗ + retry nếu có). Đóng bảng giữa chừng sẽ ngắt lượt đang chạy.
8. Lấy file trong vault: `sources/research/<slug>/` và `exports/research/<slug>/`.

**Chat (tuỳ chọn):** nhờ Javis "chạy workflow nghiên cứu thị trường chuyên sâu với brief: ..." - vẫn nên chạy từ Studio để theo dõi bước rõ hơn.

## Cấu trúc thư mục đầu ra

```
sources/research/<slug>/
  00-index.md
  01-research-findings.md
  02-survey-plan.md
  03-competitors-personas.md
  04-visual-brief.md
  05-proposal.md
attachments/research/<slug>/
exports/research/<slug>/
  report.html | report.pdf | deck.pptx | manifest.json
```

## Skill / agent (đã đồng bộ)

- Nghiên cứu: agent `nghien-cuu-thi-truong-sau` → skill `nghien-cuu-thi-truong`, `deep-research`
- Proposal: agent `soan-proposal-chien-luoc` → skill `proposal-chien-luoc` (+ đọc nghiên cứu)
- Kiểm chứng: checklist cả hai skill
- Xuất: skill `xuat-goi-nghien-cuu`
- Ý tưởng sản phẩm/module mới (không thuộc pipeline này): workflow **`thiet-ke-tu-y-tuong`** → duyệt → **`lap-ke-hoach-tu-spec`** (skill `brainstorming` + `writing-plans`)

## Lưu ý

- Workflow đang **bật**. PDF cần Chrome trên máy chạy Javis; thiếu thì còn HTML + PPTX + MD.
- Không dùng em dash trong đầu ra.
